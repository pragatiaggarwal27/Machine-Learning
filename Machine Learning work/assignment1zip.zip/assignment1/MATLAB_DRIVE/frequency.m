%frequency-utility-for-question8


function A = frequency(arr) 
    A = zeros(100, 2);
    len = size(arr, 2);
    for i = 1 : 1 : 100
        c = 0;
        for j = 1 : 1 : len
            if arr(j) == i
                c = c + 1;
            end
        end
        A(i,1) = i; 
        A(i,2) = c;
    end
end

