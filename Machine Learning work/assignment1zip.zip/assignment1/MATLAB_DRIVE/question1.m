% question 1
R = input("Enter R");
M = input("Enter M");
W = input("Enter W");

coefficients = [R, R*M, W, 25];
roots_of_equation = roots(coefficients);

disp("The Roots are:")
disp(roots_of_equation)


