

% 10.1
img = imread('nasa--hI5dX2ObAs-unsplash.jpg');

figure;
imshow(img);
title('Original Image');
saveas(gcf, 'fig1.png');


img_resized = imresize(img, 0.5);


figure;
imshow(img_resized);
title('Resized Image to Half');
saveas(gcf, 'fig2.png'); 

% 10.2
img_gray = rgb2gray(img_resized);

figure;
imshow(img_gray);
title('Grayscale Image');
saveas(gcf, 'fig3.png'); 

% 10.3
img_gray_1D = img_gray(:);

% 10.4
img_gray_restored = reshape(img_gray_1D, size(img_gray));

figure;
imshow(img_gray_restored);
title('Restored Grayscale Image from 1D Array');
saveas(gcf, 'fig4.png');

% 10.5
img_color_restored = ind2rgb(im2uint8(mat2gray(img_gray_restored)), jet(256));




figure;
imshow(img_color_restored);
title('Artificially Colorized Image from Grayscale');
saveas(gcf, 'fig5.png');
