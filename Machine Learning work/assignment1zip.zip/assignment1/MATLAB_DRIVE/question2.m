%question2 
a = [3, 4, 5];
b = [7, 8, 9];

dot_prod = dot(a, b);
cross_prod = cross(a, b);

disp("Dot Prod Equals:")
disp(dot_prod);
disp("Cross Prod Equals:")
disp(cross_prod)