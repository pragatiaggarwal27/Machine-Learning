%question 3 
n = input("Enter the size");

A = rand(n, n);

for i = 1:1:n
   A(i, 1) = i;
end

A