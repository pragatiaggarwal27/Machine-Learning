%question4
A = rand(3, 3);
det(A)