%question 5
n = input("Enter the length of the array.");
disp(sprintf("Enter %d numbers.", n));

arr = zeros(1, n);

for i = 1 : 1 : n
    arr(i) = input("Number :");
end

for i = 1 : 1 : n
    for j = 1 : 1 :  n - i
        if arr(j) > arr(j + 1)
            temp = arr(j)
            arr(j) = arr(j + 1)
            arr(j + 1) = temp
        end
    end
end

%displaying sorted array

for i = 1 : 1 : n
    fprintf("%d ", arr(i))
end
fprintf("\n")

