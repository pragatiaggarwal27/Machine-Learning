%question6

r = input("Enter the radius");

theta = linspace(0, 2*pi, 100);


x = r * cos(theta);
y = r * sin(theta);


figure;
plot(x, y, 'b');
axis equal;


title('Rajdeep.');

