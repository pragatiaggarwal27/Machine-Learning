%question7

r = input("Enter the radius.");

theta = linspace(0, 2*pi, 100);

x = r * cos(theta);
y = r * sin(theta);
z = zeros(1,100);

figure;
plot3(x, y, z, 'b');
axis equal;

title ("Rajdeep.")
