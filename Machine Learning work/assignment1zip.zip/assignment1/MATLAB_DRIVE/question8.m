%question8

N = input("Enter the size of the array.");
arr = randi([1, 100], 1, N);
A = frequency(arr);
disp(A);

%8.1
 
x = A(1:100, 1);
y = A(1:100, 2);
 
figure;
plot(x, y, 'r')
 
%8.2
 
for i = 1 : 1 : 100
    x = i;
    y = A(i, 2);
    if mod(1, 2) == 0
        plot(x, y, "dr")
    else
        hold on;
        plot(x, y, "go")
    end
end

%8.3

%doubt why is the mean not floating point

avg = mean(A(1:100, 2));
x_coordinates = zeros(1, 100);
for i = 1 : 1 : 100
    x_coordinates(1, i) = i;
end
y_coordinates = zeros(1, 100);
y_coordinate(:) = avg;

figure;
plot(x_coordinates, y_coordinates, "r:");
grid on;